#ifndef MAP_H
#define MAP_H

#include <vector>

#include "mingl/mingl.h"

namespace environment {
    void intiMap(MinGL &window);
}

#endif // MAP_H
